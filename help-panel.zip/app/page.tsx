"use client"

import HelpPanel from "@/components/help/help-panel"

export default function Page() {
  return (
    <div>
      <HelpPanel />
    </div>
  )
}
