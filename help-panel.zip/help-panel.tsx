"use client"

import { useState } from "react"
import {
  Book,
  HelpCircle,
  Search,
  ChevronRight,
  FileText,
  Lightbulb,
  Settings,
  PanelRightOpen,
  PanelRightClose,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Separator } from "@/components/ui/separator"
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"

interface HelpContent {
  id: string
  title: string
  description: string
  content: string
  category: "manual" | "reference" | "tips"
  tags: string[]
}

const helpContent: HelpContent[] = [
  {
    id: "dashboard-overview",
    title: "Dashboard Overview",
    description: "Understanding your main dashboard",
    content:
      "The dashboard provides a comprehensive view of your account activity, recent transactions, and key metrics. Use the navigation cards to quickly access different sections of the application.",
    category: "manual",
    tags: ["dashboard", "overview", "navigation"],
  },
  {
    id: "user-settings",
    title: "User Settings",
    description: "Managing your account preferences",
    content:
      "Access your user settings to update your profile information, change password, manage notifications, and configure application preferences. Settings are automatically saved when changed.",
    category: "manual",
    tags: ["settings", "profile", "account"],
  },
  {
    id: "keyboard-shortcuts",
    title: "Keyboard Shortcuts",
    description: "Speed up your workflow with shortcuts",
    content:
      "• Ctrl+K: Open command palette\n• Ctrl+/: Toggle help panel\n• Ctrl+B: Toggle sidebar\n• Esc: Close modals and panels",
    category: "reference",
    tags: ["shortcuts", "keyboard", "productivity"],
  },
  {
    id: "data-export",
    title: "Data Export",
    description: "How to export your data",
    content:
      "You can export your data in multiple formats including CSV, JSON, and PDF. Go to Settings > Data Export to access export options. Large exports may take a few minutes to process.",
    category: "manual",
    tags: ["export", "data", "csv", "pdf"],
  },
  {
    id: "performance-tips",
    title: "Performance Tips",
    description: "Optimize your experience",
    content:
      "• Use filters to reduce data load\n• Enable dark mode to reduce eye strain\n• Bookmark frequently used pages\n• Clear browser cache if experiencing issues",
    category: "tips",
    tags: ["performance", "optimization", "tips"],
  },
]

interface HelpPanelProps {
  currentContext?: string
  onContextChange?: (context: string) => void
}

export default function HelpPanel({ currentContext = "dashboard-overview", onContextChange }: HelpPanelProps) {
  const [searchQuery, setSearchQuery] = useState("")
  const [selectedContent, setSelectedContent] = useState<HelpContent | null>(
    helpContent.find((item) => item.id === currentContext) || helpContent[0],
  )
  const [isSharedMode, setIsSharedMode] = useState(false)
  const [isHelpOpen, setIsHelpOpen] = useState(false)

  const filteredContent = helpContent.filter(
    (item) =>
      item.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.tags.some((tag) => tag.toLowerCase().includes(searchQuery.toLowerCase())),
  )

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case "manual":
        return <Book className="h-4 w-4" />
      case "reference":
        return <FileText className="h-4 w-4" />
      case "tips":
        return <Lightbulb className="h-4 w-4" />
      default:
        return <HelpCircle className="h-4 w-4" />
    }
  }

  const getCategoryColor = (category: string) => {
    switch (category) {
      case "manual":
        return "bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-300"
      case "reference":
        return "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300"
      case "tips":
        return "bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-300"
      default:
        return "bg-gray-100 text-gray-800 dark:bg-gray-900 dark:text-gray-300"
    }
  }

  const HelpPanelContent = ({ isShared = false }: { isShared?: boolean }) => (
    <div className={`${isShared ? "h-full" : ""} space-y-4`}>
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <HelpCircle className="h-5 w-5" />
          <span className="font-semibold">Help & Documentation</span>
        </div>
        {isShared && (
          <Button variant="ghost" size="sm" onClick={() => setIsSharedMode(false)} className="h-8 w-8 p-0">
            <PanelRightClose className="h-4 w-4" />
          </Button>
        )}
      </div>

      <div className="relative">
        <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
        <Input
          placeholder="Search help topics..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="pl-10"
        />
      </div>

      <Tabs defaultValue="content" className="w-full">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="content">Help Topics</TabsTrigger>
          <TabsTrigger value="details">Details</TabsTrigger>
        </TabsList>

        <TabsContent value="content" className="mt-4">
          <ScrollArea className={`${isShared ? "h-[calc(100vh-200px)]" : "h-[400px]"} pr-4`}>
            <div className="space-y-2">
              {filteredContent.map((item) => (
                <Card
                  key={item.id}
                  className={`cursor-pointer transition-colors hover:bg-muted/50 ${
                    selectedContent?.id === item.id ? "ring-2 ring-primary" : ""
                  }`}
                  onClick={() => setSelectedContent(item)}
                >
                  <CardHeader className="pb-2">
                    <div className="flex items-center justify-between">
                      <CardTitle className="text-sm flex items-center gap-2">
                        {getCategoryIcon(item.category)}
                        {item.title}
                      </CardTitle>
                      <ChevronRight className="h-4 w-4 text-muted-foreground" />
                    </div>
                    <CardDescription className="text-xs">{item.description}</CardDescription>
                  </CardHeader>
                  <CardContent className="pt-0">
                    <div className="flex items-center gap-2">
                      <Badge variant="secondary" className={`text-xs ${getCategoryColor(item.category)}`}>
                        {item.category}
                      </Badge>
                      <div className="flex gap-1">
                        {item.tags.slice(0, 2).map((tag) => (
                          <Badge key={tag} variant="outline" className="text-xs">
                            {tag}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </ScrollArea>
        </TabsContent>

        <TabsContent value="details" className="mt-4">
          {selectedContent ? (
            <ScrollArea className={`${isShared ? "h-[calc(100vh-200px)]" : "h-[400px]"} pr-4`}>
              <div className="space-y-4">
                <div>
                  <div className="flex items-center gap-2 mb-2">
                    {getCategoryIcon(selectedContent.category)}
                    <h3 className="text-lg font-semibold">{selectedContent.title}</h3>
                  </div>
                  <p className="text-sm text-muted-foreground mb-4">{selectedContent.description}</p>
                </div>

                <Separator />

                <div>
                  <h4 className="font-medium mb-2">Content</h4>
                  <div className="text-sm leading-relaxed whitespace-pre-line">{selectedContent.content}</div>
                </div>

                <Separator />

                <div>
                  <h4 className="font-medium mb-2">Tags</h4>
                  <div className="flex flex-wrap gap-1">
                    {selectedContent.tags.map((tag) => (
                      <Badge key={tag} variant="outline" className="text-xs">
                        {tag}
                      </Badge>
                    ))}
                  </div>
                </div>
              </div>
            </ScrollArea>
          ) : (
            <div className="flex items-center justify-center h-[200px] text-muted-foreground">
              <div className="text-center">
                <HelpCircle className="h-8 w-8 mx-auto mb-2" />
                <p>Select a help topic to view details</p>
              </div>
            </div>
          )}
        </TabsContent>
      </Tabs>
    </div>
  )

  return (
    <div className="flex h-screen w-full">
      {/* Main Content Area */}
      <div className={`flex-1 transition-all duration-300 ${isSharedMode ? "mr-0" : ""}`}>
        <div className="h-full p-6 overflow-auto">
          <div className="max-w-4xl mx-auto space-y-6">
            <div className="flex items-center justify-between">
              <h1 className="text-3xl font-bold">Your Application</h1>
              <div className="flex items-center gap-2">
                {!isSharedMode && (
                  <Button variant="outline" size="sm" onClick={() => setIsSharedMode(true)}>
                    <PanelRightOpen className="h-4 w-4 mr-2" />
                    Pin Help
                  </Button>
                )}
                {!isSharedMode && (
                  <Sheet open={isHelpOpen} onOpenChange={setIsHelpOpen}>
                    <SheetTrigger asChild>
                      <Button variant="outline" size="sm">
                        <HelpCircle className="h-4 w-4 mr-2" />
                        Help
                      </Button>
                    </SheetTrigger>
                    <SheetContent side="right" className="w-[400px] sm:w-[540px] p-6">
                      <HelpPanelContent />
                    </SheetContent>
                  </Sheet>
                )}
              </div>
            </div>

            {/* Sample content cards that could trigger contextual help */}
            <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
              <Card
                className="cursor-pointer hover:shadow-md transition-shadow"
                onClick={() => {
                  setSelectedContent(helpContent.find((item) => item.id === "dashboard-overview") || helpContent[0])
                  onContextChange?.("dashboard-overview")
                }}
              >
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Settings className="h-5 w-5" />
                    Dashboard
                  </CardTitle>
                  <CardDescription>View your main dashboard and analytics</CardDescription>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-muted-foreground">
                    Click here to access your main dashboard with all key metrics and recent activity.
                  </p>
                </CardContent>
              </Card>

              <Card
                className="cursor-pointer hover:shadow-md transition-shadow"
                onClick={() => {
                  setSelectedContent(helpContent.find((item) => item.id === "user-settings") || helpContent[0])
                  onContextChange?.("user-settings")
                }}
              >
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Settings className="h-5 w-5" />
                    Settings
                  </CardTitle>
                  <CardDescription>Manage your account preferences</CardDescription>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-muted-foreground">
                    Configure your profile, notifications, and application settings.
                  </p>
                </CardContent>
              </Card>

              <Card
                className="cursor-pointer hover:shadow-md transition-shadow"
                onClick={() => {
                  setSelectedContent(helpContent.find((item) => item.id === "data-export") || helpContent[0])
                  onContextChange?.("data-export")
                }}
              >
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <FileText className="h-5 w-5" />
                    Data Export
                  </CardTitle>
                  <CardDescription>Export your data in various formats</CardDescription>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-muted-foreground">
                    Download your data as CSV, JSON, or PDF files for external use.
                  </p>
                </CardContent>
              </Card>
            </div>

            {/* Additional content to show scrolling */}
            <div className="space-y-4">
              <h2 className="text-2xl font-semibold">More Content</h2>
              <div className="grid gap-4 md:grid-cols-2">
                {Array.from({ length: 6 }).map((_, i) => (
                  <Card key={i}>
                    <CardHeader>
                      <CardTitle>Feature {i + 1}</CardTitle>
                      <CardDescription>Description for feature {i + 1}</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <p className="text-sm text-muted-foreground">
                        This is some sample content to demonstrate the layout and scrolling behavior.
                      </p>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Shared Mode Help Panel */}
      {isSharedMode && (
        <div className="w-[600px] border-l bg-background flex flex-col">
          <div className="p-6 border-b">
            <HelpPanelContent isShared={true} />
          </div>
        </div>
      )}
    </div>
  )
}
